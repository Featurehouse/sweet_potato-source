//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package bilibili.ywsuoyi.gui;

import net.minecraft.item.ItemStack;

public class Icon {
    public int x;
    public int y;
    public ItemStack i;

    public Icon(int x, int y, ItemStack i) {
        this.i = i;
        this.x = x;
        this.y = y;
    }
}

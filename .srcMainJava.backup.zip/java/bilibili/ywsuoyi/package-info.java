/**
 * <h1>Remake: bilibili.ywsuoyi</h1>
 * <p>Code in this package are NOT full copy from <i>ywlib</i>.</p>
 * <p>In this package, teddyxlandlee does some edit from the package
 * because it is not very applicative to <i>Sweet Potato Mod</i>.</p>
 * @author YWsuoyi, teddyxlandlee
 * @since beta 1.0.0
 */
package bilibili.ywsuoyi;
package io.featurehouse.annotation;

public @interface ReallyOverride {
    String as() default "";
}
package io.featurehouse.annotation;

public @interface NeedToConfirm {
}
package io.featurehouse.annotation;

public @interface FromXmas2020 {
    String value() default "";
}

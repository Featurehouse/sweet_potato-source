package io.featurehouse.annotation;

@Deprecated
public @interface InDebugUse {
}

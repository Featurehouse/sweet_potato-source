package io.featurehouse.annotation;

public @interface FabricApiRegistry {
}

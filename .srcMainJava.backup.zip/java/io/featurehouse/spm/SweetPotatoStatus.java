package io.featurehouse.spm;

public enum SweetPotatoStatus {
    RAW,
    BAKED,
    ENCHANTED,
    CROP
}

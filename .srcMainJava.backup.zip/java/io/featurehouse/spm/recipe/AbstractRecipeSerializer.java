package io.featurehouse.spm.recipe;

import net.minecraft.recipe.Recipe;
import net.minecraft.recipe.RecipeSerializer;

public abstract class AbstractRecipeSerializer<T extends Recipe<?>> implements RecipeSerializer<T> {
}
